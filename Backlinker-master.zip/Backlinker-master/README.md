# Backlinker - 3k Url Backlink Generator

USE TOOL;

 $ git clone https://github.com/h4cklinker/Backlinker.git
 $ cd Backlinker
 $ python backlinker.py
 
Wrt. Domain Adress Enter RUN! And Waiting.. / Domaininizi yazıp (siteadresin.com) enter tusunu basip bekleyin.

![backlink](https://github.com/h4cklinker/Backlinker/blob/master/src1.png?raw=true)
